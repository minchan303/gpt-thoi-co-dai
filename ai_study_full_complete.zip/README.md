AI Study Assistant - Full Project
================================

What's included:
- server.js (Express backend)
- public/index.html (frontend UI)
- package.json
- .env.example
- README

Quick start:
1. Unzip the project folder.
2. Copy .env.example -> .env and set your OPENAI_API_KEY (must be a valid secret key).
3. Open terminal in project folder.
4. Run: npm install
5. Run: node server.js
6. Open browser: http://localhost:3000
   Or from another device on same Wi-Fi: http://<YOUR_LAN_IP>:3000

Notes:
- Do NOT expose your API key publicly.
- If you want external access, use ngrok or deploy to a server.
